Forward Translation (LaTeX -> CAS):
1) java -jar latex-to-cas-translator.jar

Backward Translation (Maple -> LaTeX):
1) Change Maple installation directory in libs/maple_config.properties
2) java -jar maple-translator.jar